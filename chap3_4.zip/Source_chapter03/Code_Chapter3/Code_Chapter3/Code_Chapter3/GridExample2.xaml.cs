﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Code_Chapter3
{
    public partial class GridExample2 : ContentPage
    {
        public GridExample2()
        {
            InitializeComponent();
        }
    }
}

