﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Code_Chapter3
{
    public partial class AbsoluteLayoutExample : ContentPage
    {
        public AbsoluteLayoutExample()
        {
            InitializeComponent();
        }
    }
}

